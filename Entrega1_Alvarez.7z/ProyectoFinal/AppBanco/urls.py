from django.urls import path
from .views import * 

urlpatterns = [
    path('',inicio,name='inicio'),
    path('clientes/', clientes,name='clientes'),
    path('productos/', productos,name='productos'),
    path('sucursales/', sucursales,name='sucursales'),
    path('buscar_cliente/',buscar_cliente,name='buscar_cliente'),
    path('buscar/',buscar,name='buscar'),
]